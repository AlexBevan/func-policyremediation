Azurite: Start
func start